'use client'

export default function Home() {
  return (
    <iframe
      src="/MIGROPP.html"
      style={{
        width: '100vw',
        height: '100vh',
        border: 'none',
        overflow: 'hidden',
        display: 'block',
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        zIndex: 1,
      }}
      title="MIGROPP"
      allow="fullscreen"
      suppressHydrationWarning
    />
  )
}
